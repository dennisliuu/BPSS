# BPSS - Relayer GUI tool

```bash
# Install dependencies
npm install
# Run the app
npm start
```

<img src="https://i.imgur.com/HZFQiXd.jpg" width="500">