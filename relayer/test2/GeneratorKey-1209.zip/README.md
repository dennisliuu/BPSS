## Generate Public / Private Key

```
node generatorKey.js
```

## Rename 

```
fs.writeFile('private.pem [YOUR NAME]')
```
